# 🍲 Molo — Batch cooking à domicile

Site web Nuxt 3 pour **Molo**, service de batch cooking à domicile dans la métropole lilloise.

## Démarrer le projet

```bash
# Installer les dépendances
npm install

# Lancer le serveur de développement sur http://localhost:3000
npm run dev

# Générer le site statique
npm run generate

# Build pour la production
npm run build
```

## Structure du projet

```
molo/
├── app.vue                    # Point d'entrée
├── nuxt.config.ts             # Configuration Nuxt
├── assets/css/
│   └── main.css               # Variables CSS & styles globaux
├── layouts/
│   └── default.vue            # Layout principal (navbar + footer)
├── pages/
│   ├── index.vue              # Page d'accueil
│   └── reserver.vue           # Page de réservation
├── components/
│   ├── AppNavbar.vue          # Navigation
│   ├── AppFooter.vue          # Pied de page
│   ├── HeroSection.vue        # Section héros
│   ├── TrustBar.vue           # Barre de confiance
│   ├── HowItWorks.vue         # Comment ça marche
│   ├── MenusSection.vue       # Nos menus (avec onglets)
│   ├── PricingSection.vue     # Tarifs
│   ├── ZonesSection.vue       # Zones desservies
│   ├── TestimonialsSection.vue # Témoignages
│   ├── FaqSection.vue         # FAQ interactive
│   └── CtaSection.vue         # Call-to-action final
└── public/
    └── favicon.svg
```

## Design

- **Palette** : Terracotta, vert forêt, crème, ocre
- **Typographie** : Playfair Display (titres) + DM Sans (corps) + Caveat (accent)
- **Esthétique** : Chaleureux, organique, artisanal, fait-maison

## Pages incluses

- `/` — Landing page complète avec 8 sections
- `/reserver` — Formulaire de réservation multi-étapes

## Technologies

- **Nuxt 3** (Vue 3 + Vite)
- **CSS Variables** pour le design system
- **Animations** CSS natives (blobs, floats, fadeUp)
- **Responsive** mobile-first
