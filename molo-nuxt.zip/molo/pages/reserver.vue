<template>
  <div class="booking-page">
    <div class="booking-hero">
      <div class="container">
        <span class="booking-badge">📅 Réservation en ligne</span>
        <h1 class="booking-title">Réservez votre session Molo</h1>
        <p class="booking-sub">Simple, rapide, sans engagement. Profitez de 10% de réduction sur votre première session.</p>
      </div>
    </div>

    <div class="container booking-content">
      <form class="booking-form" @submit.prevent="handleSubmit">
        <!-- Step 1 -->
        <div class="form-section" :class="{ 'form-section--active': step >= 1 }">
          <div class="form-section__header">
            <div class="step-badge">1</div>
            <h2>Votre formule</h2>
          </div>
          <div class="plans-select">
            <label
              class="plan-option"
              v-for="plan in plans"
              :key="plan.id"
              :class="{ 'plan-option--selected': form.plan === plan.id }"
            >
              <input type="radio" v-model="form.plan" :value="plan.id" hidden />
              <div class="plan-option__icon">{{ plan.icon }}</div>
              <div class="plan-option__body">
                <div class="plan-option__name">{{ plan.name }}</div>
                <div class="plan-option__for">{{ plan.for }}</div>
              </div>
              <div class="plan-option__price">{{ plan.price }}€</div>
            </label>
          </div>
        </div>

        <!-- Step 2 -->
        <div class="form-section" :class="{ 'form-section--active': step >= 2 }">
          <div class="form-section__header">
            <div class="step-badge">2</div>
            <h2>Créneau souhaité</h2>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Date souhaitée</label>
              <input type="date" v-model="form.date" :min="minDate" />
            </div>
            <div class="form-group">
              <label>Heure de début</label>
              <select v-model="form.time">
                <option value="">Choisir un horaire</option>
                <option v-for="t in timeSlots" :key="t">{{ t }}</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Step 3 -->
        <div class="form-section" :class="{ 'form-section--active': step >= 3 }">
          <div class="form-section__header">
            <div class="step-badge">3</div>
            <h2>Vos préférences alimentaires</h2>
          </div>
          <div class="preferences-grid">
            <label
              class="pref-chip"
              v-for="pref in preferences"
              :key="pref"
              :class="{ 'pref-chip--selected': form.prefs.includes(pref) }"
            >
              <input type="checkbox" :value="pref" v-model="form.prefs" hidden />
              {{ pref }}
            </label>
          </div>
          <div class="form-group" style="margin-top:1rem">
            <label>Allergies ou restrictions particulières</label>
            <textarea v-model="form.allergies" rows="3" placeholder="Ex: allergie aux noix, intolérance au lactose..."></textarea>
          </div>
        </div>

        <!-- Step 4 -->
        <div class="form-section" :class="{ 'form-section--active': step >= 4 }">
          <div class="form-section__header">
            <div class="step-badge">4</div>
            <h2>Vos coordonnées</h2>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Prénom *</label>
              <input type="text" v-model="form.firstName" placeholder="Sophie" required />
            </div>
            <div class="form-group">
              <label>Nom *</label>
              <input type="text" v-model="form.lastName" placeholder="Dupont" required />
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Email *</label>
              <input type="email" v-model="form.email" placeholder="sophie@exemple.fr" required />
            </div>
            <div class="form-group">
              <label>Téléphone *</label>
              <input type="tel" v-model="form.phone" placeholder="06 00 00 00 00" required />
            </div>
          </div>
          <div class="form-group">
            <label>Adresse d'intervention *</label>
            <input type="text" v-model="form.address" placeholder="12 rue Victor Hugo, 59000 Lille" required />
          </div>
          <div class="form-group">
            <label>Message ou demande particulière</label>
            <textarea v-model="form.message" rows="3" placeholder="Dites-nous tout ce qui pourrait nous aider à mieux préparer votre session..."></textarea>
          </div>
        </div>

        <!-- Summary & Submit -->
        <div class="booking-summary">
          <div class="summary-line">
            <span>Formule sélectionnée</span>
            <strong>{{ selectedPlan?.name || '—' }}</strong>
          </div>
          <div class="summary-line">
            <span>Prix</span>
            <strong>{{ selectedPlan ? selectedPlan.price + '€' : '—' }}</strong>
          </div>
          <div class="summary-line summary-line--promo">
            <span>🎁 Réduction première session</span>
            <strong>-10%</strong>
          </div>
          <div class="summary-line summary-line--total">
            <span>Total</span>
            <strong>{{ selectedPlan ? Math.round(selectedPlan.price * 0.9) + '€' : '—' }}</strong>
          </div>
        </div>

        <div v-if="submitted" class="success-message">
          <div class="success-icon">✅</div>
          <h3>Demande envoyée avec succès !</h3>
          <p>Nous vous recontactons dans les 24h pour confirmer votre session et affiner votre menu personnalisé.</p>
        </div>

        <button v-else type="submit" class="submit-btn">
          Confirmer ma réservation
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </button>

        <p class="form-note">Aucun paiement requis maintenant. Nous vous contactons pour confirmer.</p>
      </form>

      <aside class="booking-aside">
        <div class="aside-card">
          <h3>✅ Ce qui est inclus</h3>
          <ul>
            <li>Courses des ingrédients frais</li>
            <li>Préparation complète des repas</li>
            <li>Mise en boîtes hermétiques</li>
            <li>Étiquetage avec date & temps de réchauffage</li>
            <li>Nettoyage de votre cuisine</li>
          </ul>
        </div>
        <div class="aside-card aside-card--dark">
          <h3>📞 Vous préférez appeler ?</h3>
          <p>Notre équipe est disponible du lundi au vendredi de 9h à 18h.</p>
          <a href="tel:+33320000000" class="aside-phone">03 20 00 00 00</a>
        </div>
        <div class="aside-card">
          <h3>⭐ 4,9/5 sur Google</h3>
          <p>Plus de 150 familles de la MEL nous font confiance chaque mois.</p>
        </div>
      </aside>
    </div>
  </div>
</template>

<script setup>
useHead({ title: 'Réserver une session – Molo' })

const step = ref(4)
const submitted = ref(false)

const form = reactive({
  plan: 'famille',
  date: '',
  time: '',
  prefs: [],
  allergies: '',
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  address: '',
  message: ''
})

const plans = [
  { id: 'solo', icon: '🥄', name: 'Solo', for: '1 à 2 personnes', price: 75 },
  { id: 'famille', icon: '🍽️', name: 'Famille', for: '3 à 4 personnes', price: 120 },
  { id: 'grande', icon: '👨‍👩‍👧‍👦', name: 'Grande famille', for: '5 personnes et +', price: 165 },
]

const selectedPlan = computed(() => plans.find(p => p.id === form.plan))

const timeSlots = ['9h00', '9h30', '10h00', '10h30', '11h00', '14h00', '14h30', '15h00', '15h30', '16h00']

const preferences = [
  'Végétarien', 'Vegan', 'Sans gluten', 'Sans lactose',
  'Halal', 'Bio / local', 'Fitness / Sport', 'Enfants',
  'Épicé', 'Gourmand', 'Light', 'Traditionnel français'
]

const minDate = computed(() => {
  const d = new Date()
  d.setDate(d.getDate() + 2)
  return d.toISOString().split('T')[0]
})

const handleSubmit = () => {
  submitted.value = true
}
</script>

<style scoped>
.booking-page {
  min-height: 100vh;
  background: var(--cream);
  padding-top: 80px;
}

.booking-hero {
  background: linear-gradient(135deg, var(--forest), #3D4F32);
  padding: 4rem 2rem;
  text-align: center;
}

.booking-badge {
  display: inline-block;
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  color: rgba(255,255,255,0.85);
  padding: 0.4rem 1rem;
  border-radius: 50px;
  font-size: 0.85rem;
  margin-bottom: 1rem;
}

.booking-title {
  font-family: var(--font-display);
  font-size: clamp(2rem, 4vw, 3rem);
  font-weight: 900;
  color: white;
  margin-bottom: 0.75rem;
}

.booking-sub {
  color: rgba(255,255,255,0.7);
  font-size: 1rem;
  max-width: 500px;
  margin: 0 auto;
}

.container {
  max-width: 1280px;
  margin: 0 auto;
}

.booking-content {
  display: grid;
  grid-template-columns: 1fr 340px;
  gap: 3rem;
  padding: 3rem 2rem 5rem;
  align-items: start;
}

.booking-form {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.form-section {
  background: white;
  border-radius: var(--radius);
  padding: 2rem;
  border: 1px solid var(--sand);
}

.form-section__header {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 1.5rem;
}

.step-badge {
  width: 32px;
  height: 32px;
  background: var(--terracotta);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 0.85rem;
  flex-shrink: 0;
}

.form-section__header h2 {
  font-family: var(--font-display);
  font-size: 1.2rem;
  font-weight: 700;
  color: var(--forest);
}

/* Plan select */
.plans-select {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.plan-option {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem 1.25rem;
  border-radius: var(--radius-sm);
  border: 2px solid var(--sand);
  cursor: pointer;
  transition: all 0.2s;
}

.plan-option:hover {
  border-color: var(--terracotta);
}

.plan-option--selected {
  border-color: var(--terracotta);
  background: rgba(196, 98, 45, 0.05);
}

.plan-option__icon { font-size: 1.5rem; }

.plan-option__body { flex: 1; }

.plan-option__name {
  font-weight: 600;
  color: var(--forest);
  font-size: 0.95rem;
}

.plan-option__for {
  font-size: 0.82rem;
  color: var(--text-muted);
}

.plan-option__price {
  font-family: var(--font-display);
  font-size: 1.3rem;
  font-weight: 700;
  color: var(--terracotta);
}

/* Form elements */
.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.form-group label {
  font-size: 0.88rem;
  font-weight: 500;
  color: var(--text-muted);
}

.form-group input,
.form-group select,
.form-group textarea {
  padding: 0.75rem 1rem;
  border-radius: var(--radius-sm);
  border: 1.5px solid var(--sand);
  font-family: var(--font-body);
  font-size: 0.95rem;
  color: var(--text);
  background: var(--cream);
  transition: border-color 0.2s;
  outline: none;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  border-color: var(--terracotta);
  background: white;
}

.form-group textarea { resize: vertical; }

/* Preferences */
.preferences-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.pref-chip {
  padding: 0.4rem 0.9rem;
  border-radius: 50px;
  border: 1.5px solid var(--sand);
  font-size: 0.85rem;
  cursor: pointer;
  transition: all 0.2s;
  color: var(--text-muted);
}

.pref-chip:hover { border-color: var(--terracotta); color: var(--terracotta); }

.pref-chip--selected {
  background: var(--terracotta);
  border-color: var(--terracotta);
  color: white;
}

/* Summary */
.booking-summary {
  background: var(--forest);
  border-radius: var(--radius);
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.summary-line {
  display: flex;
  justify-content: space-between;
  font-size: 0.9rem;
  color: rgba(255,255,255,0.65);
}

.summary-line--promo { color: var(--ochre-light); }

.summary-line--total {
  border-top: 1px solid rgba(255,255,255,0.15);
  padding-top: 0.75rem;
  font-size: 1rem;
  color: white;
}

.summary-line strong { color: inherit; }

/* Submit */
.submit-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  width: 100%;
  padding: 1.1rem;
  background: var(--terracotta);
  color: white;
  border-radius: 50px;
  font-size: 1.05rem;
  font-weight: 600;
  transition: all 0.3s ease;
}

.submit-btn:hover {
  background: var(--terracotta-dark);
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(196, 98, 45, 0.4);
}

.form-note {
  text-align: center;
  font-size: 0.8rem;
  color: var(--text-muted);
}

.success-message {
  background: rgba(107, 124, 94, 0.1);
  border: 1px solid var(--sage-light);
  border-radius: var(--radius);
  padding: 2rem;
  text-align: center;
}

.success-icon { font-size: 2.5rem; margin-bottom: 0.75rem; }

.success-message h3 {
  font-family: var(--font-display);
  font-size: 1.3rem;
  color: var(--forest);
  margin-bottom: 0.5rem;
}

.success-message p { color: var(--text-muted); font-size: 0.9rem; }

/* Aside */
.booking-aside {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  position: sticky;
  top: 100px;
}

.aside-card {
  background: white;
  border-radius: var(--radius);
  padding: 1.5rem;
  border: 1px solid var(--sand);
}

.aside-card h3 {
  font-family: var(--font-display);
  font-size: 1rem;
  color: var(--forest);
  margin-bottom: 0.75rem;
}

.aside-card p {
  font-size: 0.88rem;
  color: var(--text-muted);
  line-height: 1.6;
}

.aside-card ul {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.aside-card ul li {
  font-size: 0.88rem;
  color: var(--text-muted);
  padding-left: 1.2rem;
  position: relative;
}

.aside-card ul li::before {
  content: '✓';
  position: absolute;
  left: 0;
  color: var(--sage);
  font-weight: 700;
}

.aside-card--dark {
  background: var(--forest);
  border-color: var(--forest);
}

.aside-card--dark h3 { color: white; }
.aside-card--dark p { color: rgba(255,255,255,0.6); }

.aside-phone {
  display: block;
  margin-top: 0.75rem;
  font-size: 1.3rem;
  font-weight: 700;
  color: var(--ochre-light);
  font-family: var(--font-display);
}

@media (max-width: 900px) {
  .booking-content {
    grid-template-columns: 1fr;
  }
  .booking-aside {
    position: static;
  }
  .form-row { grid-template-columns: 1fr; }
}
</style>
