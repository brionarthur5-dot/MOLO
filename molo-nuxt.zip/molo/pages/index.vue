<template>
  <div>
    <HeroSection />
    <TrustBar />
    <HowItWorks />
    <MenusSection />
    <PricingSection />
    <ZonesSection />
    <TestimonialsSection />
    <FaqSection />
    <CtaSection />
  </div>
</template>

<script setup>
useHead({
  title: 'Molo – Batch cooking à domicile · Métropole lilloise',
  meta: [
    { name: 'description', content: 'Molo cuisine chez vous une semaine de repas faits maison, sains et savoureux. Service de batch cooking à domicile dans toute la métropole lilloise.' }
  ]
})
</script>
