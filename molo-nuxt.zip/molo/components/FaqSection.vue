<template>
  <section class="faq section">
    <div class="container">
      <div class="faq__split">
        <div class="faq__content">
          <span class="section-label">FAQ</span>
          <h2 class="section-title">Questions fréquentes</h2>
          <p class="section-desc">Vous avez d'autres questions ? Écrivez-nous !</p>
          <a href="mailto:bonjour@molo.fr" class="faq__email">bonjour@molo.fr →</a>
        </div>

        <div class="faq__list">
          <div
            class="faq-item"
            v-for="(item, i) in faqs"
            :key="i"
            :class="{ 'faq-item--open': openItem === i }"
            @click="openItem = openItem === i ? null : i"
          >
            <div class="faq-item__header">
              <span class="faq-item__q">{{ item.q }}</span>
              <span class="faq-item__icon">{{ openItem === i ? '−' : '+' }}</span>
            </div>
            <div class="faq-item__body" v-show="openItem === i">
              {{ item.a }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
const openItem = ref(0)

const faqs = [
  {
    q: 'Que comprend exactement la session ?',
    a: 'La session comprend : les courses (produits frais achetés le matin même), la préparation complète de vos repas, la mise en boîtes hermétiques étiquetées avec le nom du plat et le temps de réchauffage, et le nettoyage complet de votre cuisine après intervention.'
  },
  {
    q: 'Combien de temps dure une session ?',
    a: 'En fonction de la formule choisie, la session dure entre 2h et 4h30. Vous n\'êtes pas obligé de rester à la maison durant tout ce temps — un simple accès au logement suffit !'
  },
  {
    q: 'Est-ce que je dois fournir quoi que ce soit ?',
    a: 'Rien du tout ! Nous apportons tout : les ingrédients, les épices, les boîtes de conservation. Vous mettez simplement à disposition votre cuisine avec ses ustensiles habituels (casseroles, four, etc.).'
  },
  {
    q: 'Combien de temps se conservent les plats ?',
    a: 'Les plats cuisinés se conservent 4 à 5 jours au réfrigérateur. Nous étiqueton chaque boîte avec une date limite de consommation. La plupart se congèlent également très bien pour une conservation jusqu\'à 3 mois.'
  },
  {
    q: 'Puis-je avoir des plats adaptés à des régimes alimentaires spécifiques ?',
    a: 'Absolument. Nous adaptons nos menus à tous les régimes : végétarien, vegan, sans gluten, sans lactose, halal, régime méditerranéen, etc. Indiquez-le simplement lors de votre réservation.'
  },
  {
    q: 'Comment se passe la réservation ?',
    a: 'Réservez en ligne en sélectionnant votre créneau, votre formule et vos préférences alimentaires. Vous recevrez une confirmation par email et un appel de bienvenue de votre cuisinière assignée pour finaliser le menu personnalisé.'
  },
  {
    q: 'Que se passe-t-il si je dois annuler ?',
    a: 'Vous pouvez annuler ou reporter votre session sans frais jusqu\'à 48h avant l\'intervention. En cas d\'annulation tardive, 50% de la session est facturée pour couvrir les courses déjà effectuées.'
  },
]
</script>

<style scoped>
.faq {
  padding: 6rem 2rem;
  background: var(--warm-white);
}

.container {
  max-width: 1280px;
  margin: 0 auto;
}

.faq__split {
  display: grid;
  grid-template-columns: 1fr 2fr;
  gap: 5rem;
  align-items: start;
}

.section-label {
  display: inline-block;
  font-family: var(--font-accent);
  font-size: 1.1rem;
  color: var(--terracotta);
  margin-bottom: 0.5rem;
}

.section-title {
  font-family: var(--font-display);
  font-size: 2.2rem;
  font-weight: 900;
  color: var(--forest);
  margin-bottom: 0.75rem;
}

.section-desc {
  color: var(--text-muted);
  margin-bottom: 1rem;
}

.faq__email {
  color: var(--terracotta);
  font-weight: 500;
  font-size: 0.95rem;
}

.faq__email:hover {
  text-decoration: underline;
}

.faq__list {
  display: flex;
  flex-direction: column;
  gap: 0;
}

.faq-item {
  border-bottom: 1px solid var(--sand);
  cursor: pointer;
  transition: all 0.2s;
}

.faq-item:first-child {
  border-top: 1px solid var(--sand);
}

.faq-item--open {
  background: var(--cream);
}

.faq-item__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
  padding: 1.25rem 1rem;
}

.faq-item__q {
  font-weight: 600;
  color: var(--forest);
  font-size: 0.95rem;
}

.faq-item__icon {
  font-size: 1.5rem;
  color: var(--terracotta);
  font-weight: 300;
  flex-shrink: 0;
  line-height: 1;
}

.faq-item__body {
  padding: 0 1rem 1.25rem;
  color: var(--text-muted);
  font-size: 0.9rem;
  line-height: 1.7;
}

@media (max-width: 900px) {
  .faq__split {
    grid-template-columns: 1fr;
    gap: 2.5rem;
  }
}
</style>
