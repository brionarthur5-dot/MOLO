<template>
  <header :class="['navbar', { 'navbar--scrolled': scrolled, 'navbar--open': menuOpen }]">
    <div class="navbar__inner">
      <NuxtLink to="/" class="navbar__logo">
        <span class="logo-mark">M</span>
        <span class="logo-text">molo</span>
      </NuxtLink>

      <nav class="navbar__nav">
        <NuxtLink to="/#comment" class="nav-link">Comment ça marche</NuxtLink>
        <NuxtLink to="/#menus" class="nav-link">Nos menus</NuxtLink>
        <NuxtLink to="/#tarifs" class="nav-link">Tarifs</NuxtLink>
        <NuxtLink to="/#zones" class="nav-link">Zones</NuxtLink>
        <NuxtLink to="/#temoignages" class="nav-link">Avis</NuxtLink>
      </nav>

      <div class="navbar__actions">
        <NuxtLink to="/reserver" class="btn-cta">Réserver une session</NuxtLink>
        <button class="burger" @click="menuOpen = !menuOpen" :aria-expanded="menuOpen">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>

    <!-- Mobile menu -->
    <div class="mobile-menu" v-show="menuOpen">
      <nav class="mobile-nav">
        <NuxtLink to="/#comment" class="mobile-link" @click="menuOpen = false">Comment ça marche</NuxtLink>
        <NuxtLink to="/#menus" class="mobile-link" @click="menuOpen = false">Nos menus</NuxtLink>
        <NuxtLink to="/#tarifs" class="mobile-link" @click="menuOpen = false">Tarifs</NuxtLink>
        <NuxtLink to="/#zones" class="mobile-link" @click="menuOpen = false">Zones</NuxtLink>
        <NuxtLink to="/#temoignages" class="mobile-link" @click="menuOpen = false">Avis</NuxtLink>
        <NuxtLink to="/reserver" class="btn-cta btn-cta--full" @click="menuOpen = false">Réserver une session</NuxtLink>
      </nav>
    </div>
  </header>
</template>

<script setup>
const scrolled = ref(false)
const menuOpen = ref(false)

onMounted(() => {
  window.addEventListener('scroll', () => {
    scrolled.value = window.scrollY > 40
  })
})
</script>

<style scoped>
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 100;
  padding: 1.25rem 2rem;
  transition: all 0.4s ease;
}

.navbar--scrolled {
  background: rgba(250, 246, 240, 0.95);
  backdrop-filter: blur(12px);
  padding: 0.875rem 2rem;
  box-shadow: 0 2px 30px rgba(26, 18, 8, 0.08);
}

.navbar__inner {
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 2rem;
}

.navbar__logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  text-decoration: none;
}

.logo-mark {
  width: 38px;
  height: 38px;
  background: var(--terracotta);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-display);
  font-weight: 900;
  font-size: 1.2rem;
  flex-shrink: 0;
}

.logo-text {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 1.6rem;
  color: var(--forest);
  letter-spacing: -0.02em;
}

.navbar__nav {
  display: flex;
  align-items: center;
  gap: 2rem;
}

.nav-link {
  font-size: 0.9rem;
  font-weight: 500;
  color: var(--text-muted);
  transition: color 0.2s;
  position: relative;
}

.nav-link::after {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 0;
  width: 0;
  height: 2px;
  background: var(--terracotta);
  transition: width 0.3s ease;
}

.nav-link:hover {
  color: var(--terracotta);
}

.nav-link:hover::after {
  width: 100%;
}

.navbar__actions {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.btn-cta {
  background: var(--terracotta);
  color: white;
  padding: 0.65rem 1.4rem;
  border-radius: 50px;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.3s ease;
  white-space: nowrap;
}

.btn-cta:hover {
  background: var(--terracotta-dark);
  transform: translateY(-1px);
  box-shadow: 0 6px 20px rgba(196, 98, 45, 0.35);
}

.btn-cta--full {
  width: 100%;
  text-align: center;
  display: block;
  padding: 1rem;
  border-radius: var(--radius-sm);
  font-size: 1rem;
}

.burger {
  display: none;
  flex-direction: column;
  gap: 5px;
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
}

.burger span {
  display: block;
  width: 24px;
  height: 2px;
  background: var(--forest);
  border-radius: 2px;
  transition: all 0.3s ease;
}

.mobile-menu {
  display: none;
  background: var(--warm-white);
  padding: 1.5rem 2rem 2rem;
}

.mobile-nav {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  max-width: 1280px;
  margin: 0 auto;
}

.mobile-link {
  font-size: 1.1rem;
  font-weight: 500;
  color: var(--text);
  padding: 0.5rem 0;
  border-bottom: 1px solid var(--sand);
}

@media (max-width: 900px) {
  .navbar__nav { display: none; }
  .btn-cta:not(.btn-cta--full) { display: none; }
  .burger { display: flex; }
  .mobile-menu { display: block; }
}
</style>
