<template>
  <section id="temoignages" class="testimonials section">
    <div class="container">
      <div class="section-header">
        <span class="section-label">Ils nous font confiance</span>
        <h2 class="section-title">Ce que disent nos clients</h2>
      </div>

      <div class="testimonials__grid">
        <div class="testimonial" v-for="t in testimonials" :key="t.name">
          <div class="testimonial__stars">
            <span v-for="i in 5" :key="i">★</span>
          </div>
          <p class="testimonial__text">"{{ t.text }}"</p>
          <div class="testimonial__author">
            <div class="author-avatar">{{ t.initial }}</div>
            <div>
              <div class="author-name">{{ t.name }}</div>
              <div class="author-info">{{ t.info }}</div>
            </div>
          </div>
        </div>
      </div>

      <div class="testimonials__stats">
        <div class="tstat">
          <span class="tstat__num">4,9/5</span>
          <span class="tstat__label">Note moyenne sur Google</span>
        </div>
        <div class="tstat">
          <span class="tstat__num">150+</span>
          <span class="tstat__label">Familles satisfaites</span>
        </div>
        <div class="tstat">
          <span class="tstat__num">92%</span>
          <span class="tstat__label">de clients fidèles</span>
        </div>
        <div class="tstat">
          <span class="tstat__num">2 ans</span>
          <span class="tstat__label">d'expérience dans la MEL</span>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
const testimonials = [
  {
    initial: 'S',
    name: 'Sophie M.',
    info: 'Maman de 3 enfants · Villeneuve d\'Ascq',
    text: 'Molo a changé ma vie ! Chaque dimanche soir j\'avais l\'angoisse du lendemain. Maintenant je sais que tout est prêt pour la semaine. La qualité est vraiment bluffante, et les enfants adorent.'
  },
  {
    initial: 'T',
    name: 'Thomas & Léa',
    info: 'Couple actif · Lille',
    text: 'On travaille tous les deux et l\'idée de cuisiner après une longue journée... impensable. Molo nous permet de manger sainement sans se prendre la tête. Le rapport qualité-prix est excellent.'
  },
  {
    initial: 'F',
    name: 'Fatoumata K.',
    info: 'Médecin · Roubaix',
    text: 'En tant que médecin, je sais à quel point manger sainement est important. Mais je n\'ai pas le temps. Molo comprend ça. Les menus sont équilibrés, les produits frais, et le service est impeccable.'
  },
  {
    initial: 'P',
    name: 'Pierre D.',
    info: 'Retraité sportif · Marcq-en-Barœul',
    text: 'J\'ai demandé une formule fitness, et c\'est exactement ce qu\'il me fallait. Beaucoup de protéines, peu de graisses, et surtout délicieux. Mes performances en running se sont améliorées !'
  },
  {
    initial: 'C',
    name: 'Claire & Arnaud',
    info: 'Parents de jumeaux · Tourcoing',
    text: 'Avec des jumeaux de 2 ans, cuisiner c\'est mission impossible. Molo s\'adapte parfaitement à notre chaos familial. La cuisinière est d\'une gentillesse rare et les plats sont savoureux.'
  },
  {
    initial: 'M',
    name: 'Mohammed B.',
    info: 'Entrepreneur · Loos',
    text: 'J\'ai souscrit à l\'abonnement mensuel. C\'est 15% de réduction et une session garantie chaque mois. La meilleure décision que j\'ai prise cette année. Je recommande sans hésiter.'
  }
]
</script>

<style scoped>
.testimonials {
  padding: 6rem 2rem;
  background: var(--cream);
}

.container {
  max-width: 1280px;
  margin: 0 auto;
}

.section-header {
  text-align: center;
  margin-bottom: 4rem;
}

.section-label {
  display: inline-block;
  font-family: var(--font-accent);
  font-size: 1.1rem;
  color: var(--terracotta);
  margin-bottom: 0.5rem;
}

.section-title {
  font-family: var(--font-display);
  font-size: clamp(2rem, 4vw, 3rem);
  font-weight: 900;
  color: var(--forest);
}

.testimonials__grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
  margin-bottom: 4rem;
}

.testimonial {
  background: white;
  border-radius: var(--radius);
  padding: 2rem;
  border: 1px solid var(--sand);
  transition: all 0.3s ease;
}

.testimonial:hover {
  box-shadow: 0 12px 40px rgba(0,0,0,0.08);
  transform: translateY(-3px);
}

.testimonial__stars {
  color: var(--ochre);
  font-size: 1.1rem;
  letter-spacing: 2px;
  margin-bottom: 1rem;
}

.testimonial__text {
  color: var(--text);
  line-height: 1.7;
  font-size: 0.95rem;
  margin-bottom: 1.5rem;
  font-style: italic;
}

.testimonial__author {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.author-avatar {
  width: 42px;
  height: 42px;
  background: linear-gradient(135deg, var(--terracotta), var(--ochre));
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 1rem;
  flex-shrink: 0;
}

.author-name {
  font-weight: 600;
  color: var(--forest);
  font-size: 0.9rem;
}

.author-info {
  font-size: 0.78rem;
  color: var(--text-muted);
}

.testimonials__stats {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 2rem;
  background: var(--forest);
  border-radius: var(--radius);
  padding: 3rem;
}

.tstat {
  text-align: center;
}

.tstat__num {
  display: block;
  font-family: var(--font-display);
  font-size: 2.5rem;
  font-weight: 900;
  color: var(--ochre-light);
  margin-bottom: 0.25rem;
}

.tstat__label {
  font-size: 0.85rem;
  color: rgba(255,255,255,0.6);
}

@media (max-width: 1000px) {
  .testimonials__grid { grid-template-columns: 1fr 1fr; }
  .testimonials__stats { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 600px) {
  .testimonials__grid { grid-template-columns: 1fr; }
  .testimonials__stats { grid-template-columns: 1fr; gap: 1.5rem; padding: 2rem; }
}
</style>
