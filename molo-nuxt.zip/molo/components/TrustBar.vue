<template>
  <div class="trust-bar">
    <div class="trust-bar__inner">
      <div class="trust-item" v-for="item in items" :key="item.icon">
        <span class="trust-icon">{{ item.icon }}</span>
        <span class="trust-text">{{ item.text }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
const items = [
  { icon: '🥕', text: 'Produits frais & locaux' },
  { icon: '👩‍🍳', text: 'Cuisinier·e professionnel·le' },
  { icon: '🏠', text: 'Chez vous, avec vos ustensiles' },
  { icon: '🌿', text: 'Recettes saines & équilibrées' },
  { icon: '⚙️', text: 'Personnalisé à vos goûts' },
  { icon: '🥡', text: 'Tout mis en boîtes & étiqueté' },
]
</script>

<style scoped>
.trust-bar {
  background: var(--warm-white);
  border-bottom: 1px solid var(--sand);
  padding: 1.25rem 2rem;
  overflow: hidden;
}

.trust-bar__inner {
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  justify-content: center;
  gap: 2.5rem;
  flex-wrap: wrap;
}

.trust-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.88rem;
  color: var(--text-muted);
  white-space: nowrap;
}

.trust-icon {
  font-size: 1.1rem;
}

.trust-text {
  font-weight: 500;
}
</style>
