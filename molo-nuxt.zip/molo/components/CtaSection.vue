<template>
  <section class="cta-section">
    <div class="cta-section__inner">
      <div class="cta-blob cta-blob--1"></div>
      <div class="cta-blob cta-blob--2"></div>

      <div class="cta-content">
        <div class="cta-emoji">🍲</div>
        <h2 class="cta-title">
          Prêt·e à retrouver<br>
          <span class="cta-accent">le plaisir de bien manger</span> ?
        </h2>
        <p class="cta-desc">
          Réservez votre première session avec <strong>10% de réduction</strong> offerte. 
          Profitez d'une semaine de repas faits maison sans effort.
        </p>
        <div class="cta-actions">
          <NuxtLink to="/reserver" class="cta-btn cta-btn--primary">
            Je réserve ma première session
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </NuxtLink>
          <a href="tel:+33320000000" class="cta-btn cta-btn--ghost">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.44 2 2 0 0 1 3.6 1.25h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.91a16 16 0 0 0 6.06 6.06l.97-.97a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
            03 20 00 00 00
          </a>
        </div>
        <p class="cta-reassure">
          ✓ Sans engagement  ·  ✓ Annulation gratuite 48h avant  ·  ✓ Satisfait ou remboursé
        </p>
      </div>
    </div>
  </section>
</template>

<style scoped>
.cta-section {
  padding: 0 2rem 6rem;
  background: var(--cream);
}

.cta-section__inner {
  max-width: 1280px;
  margin: 0 auto;
  background: linear-gradient(135deg, var(--forest) 0%, #3D4F32 60%, #2D3B27 100%);
  border-radius: 2rem;
  padding: 5rem 3rem;
  text-align: center;
  position: relative;
  overflow: hidden;
}

.cta-blob {
  position: absolute;
  border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%;
  animation: blob 9s ease-in-out infinite;
}

.cta-blob--1 {
  width: 400px;
  height: 400px;
  background: var(--terracotta);
  top: -150px;
  left: -100px;
  opacity: 0.12;
}

.cta-blob--2 {
  width: 300px;
  height: 300px;
  background: var(--ochre);
  bottom: -100px;
  right: -80px;
  opacity: 0.12;
  animation-delay: -4s;
}

.cta-content {
  position: relative;
  z-index: 2;
}

.cta-emoji {
  font-size: 3rem;
  margin-bottom: 1.5rem;
}

.cta-title {
  font-family: var(--font-display);
  font-size: clamp(2rem, 4vw, 3.2rem);
  font-weight: 900;
  color: white;
  line-height: 1.15;
  margin-bottom: 1.25rem;
}

.cta-accent {
  color: var(--ochre-light);
  font-style: italic;
}

.cta-desc {
  color: rgba(255,255,255,0.75);
  font-size: 1.1rem;
  max-width: 540px;
  margin: 0 auto 2.5rem;
  line-height: 1.7;
}

.cta-desc strong { color: white; }

.cta-actions {
  display: flex;
  justify-content: center;
  gap: 1rem;
  flex-wrap: wrap;
  margin-bottom: 1.5rem;
}

.cta-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem 2rem;
  border-radius: 50px;
  font-size: 1rem;
  font-weight: 600;
  transition: all 0.3s ease;
}

.cta-btn--primary {
  background: var(--terracotta);
  color: white;
}

.cta-btn--primary:hover {
  background: var(--terracotta-light);
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(196, 98, 45, 0.4);
}

.cta-btn--ghost {
  background: rgba(255,255,255,0.1);
  color: white;
  border: 1px solid rgba(255,255,255,0.3);
}

.cta-btn--ghost:hover {
  background: rgba(255,255,255,0.2);
}

.cta-reassure {
  font-size: 0.82rem;
  color: rgba(255,255,255,0.45);
  letter-spacing: 0.02em;
}

@media (max-width: 600px) {
  .cta-section__inner { padding: 3rem 1.5rem; }
  .cta-btn { width: 100%; justify-content: center; }
}
</style>
