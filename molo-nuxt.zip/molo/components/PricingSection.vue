<template>
  <section id="tarifs" class="pricing section">
    <div class="pricing__bg"></div>
    <div class="container">
      <div class="section-header">
        <span class="section-label">Tarifs clairs</span>
        <h2 class="section-title">Un investissement qui<br>fait du bien</h2>
        <p class="section-desc">Tout est inclus : courses, préparation, conditionnement, nettoyage de la cuisine.</p>
      </div>

      <div class="pricing__grid">
        <div class="plan" v-for="plan in plans" :key="plan.name" :class="{ 'plan--featured': plan.featured }">
          <div class="plan__badge" v-if="plan.badge">{{ plan.badge }}</div>
          <div class="plan__icon">{{ plan.icon }}</div>
          <h3 class="plan__name">{{ plan.name }}</h3>
          <p class="plan__for">{{ plan.for }}</p>
          <div class="plan__price">
            <span class="plan__amount">{{ plan.price }}</span>
            <span class="plan__currency">€</span>
            <span class="plan__period">/session</span>
          </div>
          <p class="plan__note">{{ plan.note }}</p>
          <ul class="plan__features">
            <li v-for="feature in plan.features" :key="feature">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg>
              {{ feature }}
            </li>
          </ul>
          <NuxtLink to="/reserver" :class="['plan__cta', plan.featured ? 'plan__cta--featured' : '']">
            Réserver cette formule
          </NuxtLink>
        </div>
      </div>

      <div class="pricing__extras">
        <div class="extra" v-for="extra in extras" :key="extra.label">
          <span class="extra__icon">{{ extra.icon }}</span>
          <div>
            <strong>{{ extra.label }}</strong>
            <p>{{ extra.desc }}</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
const plans = [
  {
    icon: '🥄',
    name: 'Solo',
    for: 'Pour 1 à 2 personnes',
    price: '75',
    note: '~10€ par repas',
    badge: null,
    featured: false,
    features: [
      '5 plats préparés',
      '2h de présence',
      'Courses incluses',
      'Mise en boîtes & étiquetage',
      'Nettoyage de la cuisine'
    ]
  },
  {
    icon: '🍽️',
    name: 'Famille',
    for: 'Pour 3 à 4 personnes',
    price: '120',
    note: '~5,50€ par portion',
    badge: '⭐ Le plus populaire',
    featured: true,
    features: [
      '6 plats préparés',
      '3h à 3h30 de présence',
      'Courses incluses',
      'Mise en boîtes & étiquetage',
      'Nettoyage de la cuisine',
      'Menu personnalisé gratuit'
    ]
  },
  {
    icon: '👨‍👩‍👧‍👦',
    name: 'Grande famille',
    for: 'Pour 5 personnes et +',
    price: '165',
    note: '~5€ par portion',
    badge: null,
    featured: false,
    features: [
      '7 plats généreux préparés',
      '4h à 4h30 de présence',
      'Courses incluses',
      'Mise en boîtes & étiquetage',
      'Nettoyage de la cuisine',
      'Menu personnalisé gratuit',
      'Option livraison de repas'
    ]
  }
]

const extras = [
  { icon: '🎁', label: 'Première session -10%', desc: 'Offre de bienvenue pour tous les nouveaux clients.' },
  { icon: '🔄', label: 'Abonnement mensuel', desc: 'Réservez une session par mois et économisez 15%.' },
  { icon: '👯', label: 'Parrainage', desc: 'Parrainez un ami, chacun reçoit 10€ de réduction.' },
]
</script>

<style scoped>
.pricing {
  padding: 6rem 2rem;
  background: var(--cream);
  position: relative;
}

.pricing__bg {
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 80% 50% at 50% 0%, rgba(196, 98, 45, 0.05) 0%, transparent 70%);
  pointer-events: none;
}

.container {
  max-width: 1280px;
  margin: 0 auto;
  position: relative;
}

.section-header {
  text-align: center;
  margin-bottom: 4rem;
}

.section-label {
  display: inline-block;
  font-family: var(--font-accent);
  font-size: 1.1rem;
  color: var(--terracotta);
  margin-bottom: 0.5rem;
}

.section-title {
  font-family: var(--font-display);
  font-size: clamp(2rem, 4vw, 3rem);
  font-weight: 900;
  color: var(--forest);
  margin-bottom: 0.75rem;
}

.section-desc {
  color: var(--text-muted);
  font-size: 1rem;
  max-width: 480px;
  margin: 0 auto;
}

.pricing__grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
  margin-bottom: 4rem;
  align-items: start;
}

.plan {
  background: white;
  border-radius: var(--radius);
  padding: 2rem;
  border: 2px solid var(--sand);
  position: relative;
  transition: all 0.3s ease;
}

.plan:hover:not(.plan--featured) {
  border-color: var(--terracotta);
  transform: translateY(-4px);
}

.plan--featured {
  background: var(--forest);
  border-color: var(--forest);
  transform: scale(1.05);
  box-shadow: 0 20px 60px rgba(45, 59, 39, 0.25);
  color: white;
}

.plan__badge {
  position: absolute;
  top: -16px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--ochre);
  color: var(--forest);
  padding: 0.3rem 1rem;
  border-radius: 50px;
  font-size: 0.8rem;
  font-weight: 600;
  white-space: nowrap;
}

.plan__icon {
  font-size: 2rem;
  margin-bottom: 0.75rem;
}

.plan__name {
  font-family: var(--font-display);
  font-size: 1.4rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
  color: inherit;
}

.plan--featured .plan__name { color: white; }

.plan__for {
  font-size: 0.85rem;
  color: var(--text-muted);
  margin-bottom: 1.5rem;
}

.plan--featured .plan__for { color: rgba(255,255,255,0.6); }

.plan__price {
  display: flex;
  align-items: baseline;
  gap: 0.25rem;
  margin-bottom: 0.25rem;
}

.plan__amount {
  font-family: var(--font-display);
  font-size: 3rem;
  font-weight: 900;
  color: var(--terracotta);
}

.plan--featured .plan__amount { color: var(--ochre-light); }

.plan__currency {
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--terracotta);
}

.plan--featured .plan__currency { color: var(--ochre-light); }

.plan__period {
  font-size: 0.9rem;
  color: var(--text-muted);
}

.plan--featured .plan__period { color: rgba(255,255,255,0.5); }

.plan__note {
  font-size: 0.82rem;
  color: var(--sage);
  margin-bottom: 1.75rem;
  font-style: italic;
}

.plan--featured .plan__note { color: rgba(255,255,255,0.5); }

.plan__features {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  margin-bottom: 2rem;
}

.plan__features li {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  font-size: 0.9rem;
}

.plan__features svg {
  color: var(--sage);
  flex-shrink: 0;
}

.plan--featured .plan__features svg { color: var(--ochre-light); }

.plan__cta {
  display: block;
  text-align: center;
  padding: 0.85rem;
  border-radius: 50px;
  font-weight: 500;
  font-size: 0.95rem;
  border: 2px solid var(--terracotta);
  color: var(--terracotta);
  transition: all 0.3s ease;
}

.plan__cta:hover {
  background: var(--terracotta);
  color: white;
}

.plan__cta--featured {
  background: var(--terracotta);
  color: white;
  border-color: var(--terracotta);
}

.plan__cta--featured:hover {
  background: var(--terracotta-light);
}

.pricing__extras {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
}

.extra {
  background: white;
  border-radius: var(--radius-sm);
  padding: 1.25rem 1.5rem;
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  border: 1px solid var(--sand);
}

.extra__icon {
  font-size: 1.5rem;
  flex-shrink: 0;
}

.extra strong {
  display: block;
  color: var(--forest);
  font-size: 0.95rem;
  margin-bottom: 0.25rem;
}

.extra p {
  font-size: 0.85rem;
  color: var(--text-muted);
}

@media (max-width: 900px) {
  .pricing__grid {
    grid-template-columns: 1fr;
  }
  .plan--featured {
    transform: none;
    order: -1;
  }
  .pricing__extras {
    grid-template-columns: 1fr;
  }
}
</style>
