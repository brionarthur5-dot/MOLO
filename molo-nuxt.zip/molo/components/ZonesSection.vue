<template>
  <section id="zones" class="zones section">
    <div class="container">
      <div class="zones__split">
        <div class="zones__content">
          <span class="section-label">Où intervient-on ?</span>
          <h2 class="section-title">La métropole lilloise,<br>toute entière</h2>
          <p class="section-desc">
            Molo intervient dans toute la MEL — de Lille centre à Roubaix, Tourcoing, Villeneuve d'Ascq et au-delà. Si vous habitez dans la métropole, on vient chez vous.
          </p>

          <div class="cities-grid">
            <div class="city" v-for="city in cities" :key="city">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              {{ city }}
            </div>
          </div>

          <div class="zones__note">
            <strong>Votre ville n'est pas dans la liste ?</strong><br>
            Contactez-nous, nous étudions chaque demande au cas par cas.
          </div>

          <a href="mailto:bonjour@molo.fr" class="btn-outline">Nous contacter →</a>
        </div>

        <div class="zones__map">
          <div class="map-card">
            <div class="map-header">
              <div class="map-dot"></div>
              <span>Zone de couverture Molo</span>
            </div>
            <div class="map-visual">
              <svg viewBox="0 0 400 350" fill="none" xmlns="http://www.w3.org/2000/svg">
                <!-- Stylized MEL map -->
                <ellipse cx="200" cy="175" rx="170" ry="145" fill="rgba(107, 124, 94, 0.1)" stroke="rgba(107, 124, 94, 0.3)" stroke-width="1" stroke-dasharray="8 4"/>
                <ellipse cx="200" cy="175" rx="120" ry="100" fill="rgba(196, 98, 45, 0.08)" stroke="rgba(196, 98, 45, 0.2)" stroke-width="1"/>
                
                <!-- Center: Lille -->
                <circle cx="200" cy="175" r="10" fill="var(--terracotta)" opacity="0.9"/>
                <circle cx="200" cy="175" r="20" fill="var(--terracotta)" opacity="0.15"/>
                <text x="200" y="205" text-anchor="middle" font-size="12" fill="var(--forest)" font-family="DM Sans" font-weight="600">Lille</text>
                
                <!-- Roubaix -->
                <circle cx="265" cy="140" r="6" fill="var(--sage)" opacity="0.8"/>
                <text x="265" y="128" text-anchor="middle" font-size="11" fill="var(--text-muted)" font-family="DM Sans">Roubaix</text>
                
                <!-- Tourcoing -->
                <circle cx="250" cy="110" r="6" fill="var(--sage)" opacity="0.8"/>
                <text x="270" y="100" text-anchor="middle" font-size="11" fill="var(--text-muted)" font-family="DM Sans">Tourcoing</text>
                
                <!-- Villeneuve d'Ascq -->
                <circle cx="248" cy="190" r="6" fill="var(--sage)" opacity="0.8"/>
                <text x="280" y="198" text-anchor="middle" font-size="11" fill="var(--text-muted)" font-family="DM Sans">VdA</text>
                
                <!-- Lambersart -->
                <circle cx="165" cy="145" r="5" fill="var(--sage)" opacity="0.7"/>
                <text x="140" y="138" text-anchor="middle" font-size="10" fill="var(--text-muted)" font-family="DM Sans">Lambersart</text>
                
                <!-- Wasquehal -->
                <circle cx="270" cy="162" r="5" fill="var(--sage)" opacity="0.7"/>
                <text x="300" y="168" text-anchor="middle" font-size="10" fill="var(--text-muted)" font-family="DM Sans">Wasquehal</text>
                
                <!-- Marcq en Baroeul -->
                <circle cx="220" cy="128" r="5" fill="var(--sage)" opacity="0.7"/>
                <text x="220" y="116" text-anchor="middle" font-size="10" fill="var(--text-muted)" font-family="DM Sans">Marcq</text>
                
                <!-- Loos -->
                <circle cx="165" cy="205" r="5" fill="var(--sage)" opacity="0.7"/>
                <text x="148" y="218" text-anchor="middle" font-size="10" fill="var(--text-muted)" font-family="DM Sans">Loos</text>
                
                <!-- Hellemmes -->
                <circle cx="230" cy="200" r="5" fill="var(--sage)" opacity="0.7"/>
              </svg>
            </div>
            <div class="map-footer">
              <span>🏙️ Toute la MEL couverte</span>
              <span>Intervention sous 48h</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
const cities = [
  'Lille', 'Roubaix', 'Tourcoing', 'Villeneuve d\'Ascq',
  'Lambersart', 'Marcq-en-Barœul', 'Wasquehal', 'Loos',
  'Hellemmes', 'Croix', 'Hem', 'Mons-en-Barœul',
  'Lomme', 'Wattignies', 'La Madeleine', 'Saint-André'
]
</script>

<style scoped>
.zones {
  padding: 6rem 2rem;
  background: var(--warm-white);
}

.container {
  max-width: 1280px;
  margin: 0 auto;
}

.zones__split {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5rem;
  align-items: center;
}

.section-label {
  display: inline-block;
  font-family: var(--font-accent);
  font-size: 1.1rem;
  color: var(--terracotta);
  margin-bottom: 0.5rem;
}

.section-title {
  font-family: var(--font-display);
  font-size: clamp(1.8rem, 3.5vw, 2.75rem);
  font-weight: 900;
  color: var(--forest);
  margin-bottom: 1rem;
}

.section-desc {
  color: var(--text-muted);
  line-height: 1.75;
  margin-bottom: 2rem;
}

.cities-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.5rem 1rem;
  margin-bottom: 1.5rem;
}

.city {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  font-size: 0.88rem;
  color: var(--text-muted);
}

.city svg {
  color: var(--terracotta);
  flex-shrink: 0;
}

.zones__note {
  background: var(--cream);
  border-radius: var(--radius-sm);
  padding: 1rem 1.25rem;
  margin-bottom: 1.5rem;
  font-size: 0.88rem;
  color: var(--text-muted);
  border-left: 3px solid var(--ochre);
}

.zones__note strong {
  display: block;
  color: var(--forest);
  margin-bottom: 0.2rem;
}

.btn-outline {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  border-radius: 50px;
  border: 2px solid var(--terracotta);
  color: var(--terracotta);
  font-weight: 500;
  font-size: 0.95rem;
  transition: all 0.3s ease;
}

.btn-outline:hover {
  background: var(--terracotta);
  color: white;
}

/* Map */
.map-card {
  background: white;
  border-radius: var(--radius);
  overflow: hidden;
  box-shadow: 0 12px 50px rgba(0,0,0,0.1);
  border: 1px solid var(--sand);
}

.map-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem 1.5rem;
  border-bottom: 1px solid var(--sand);
  font-size: 0.88rem;
  font-weight: 500;
  color: var(--text-muted);
}

.map-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--terracotta);
  animation: float 2s ease-in-out infinite;
}

.map-visual {
  padding: 1rem;
}

.map-visual svg {
  width: 100%;
}

.map-footer {
  display: flex;
  justify-content: space-between;
  padding: 0.75rem 1.5rem;
  background: var(--cream);
  font-size: 0.8rem;
  color: var(--text-muted);
  border-top: 1px solid var(--sand);
}

@media (max-width: 900px) {
  .zones__split {
    grid-template-columns: 1fr;
    gap: 3rem;
  }
}
</style>
