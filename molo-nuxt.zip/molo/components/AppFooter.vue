<template>
  <footer class="footer">
    <div class="footer__inner">
      <div class="footer__brand">
        <NuxtLink to="/" class="footer__logo">
          <span class="logo-mark">M</span>
          <span class="logo-text">molo</span>
        </NuxtLink>
        <p class="footer__tagline">
          La cuisine du quotidien,<br>sans le quotidien de la cuisine.
        </p>
        <div class="footer__social">
          <a href="https://instagram.com" target="_blank" class="social-link" aria-label="Instagram">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="20" height="20"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
          </a>
          <a href="https://facebook.com" target="_blank" class="social-link" aria-label="Facebook">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="20" height="20"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
          </a>
        </div>
      </div>

      <div class="footer__col">
        <h4>Service</h4>
        <ul>
          <li><a href="/#comment">Comment ça marche</a></li>
          <li><a href="/#menus">Nos menus</a></li>
          <li><a href="/#tarifs">Tarifs</a></li>
          <li><a href="/#zones">Zones desservies</a></li>
          <li><NuxtLink to="/reserver">Réserver</NuxtLink></li>
        </ul>
      </div>

      <div class="footer__col">
        <h4>À propos</h4>
        <ul>
          <li><NuxtLink to="/a-propos">Notre histoire</NuxtLink></li>
          <li><a href="/#temoignages">Témoignages</a></li>
          <li><a href="/faq">FAQ</a></li>
          <li><a href="/blog">Blog recettes</a></li>
        </ul>
      </div>

      <div class="footer__col">
        <h4>Contact</h4>
        <ul>
          <li><a href="mailto:bonjour@molo.fr">bonjour@molo.fr</a></li>
          <li><a href="tel:+33320000000">03 20 00 00 00</a></li>
          <li class="footer__zone">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            Métropole de Lille
          </li>
        </ul>
      </div>
    </div>

    <div class="footer__bottom">
      <p>© 2024 Molo — Batch cooking à domicile. Tous droits réservés.</p>
      <div class="footer__legal">
        <a href="/mentions-legales">Mentions légales</a>
        <a href="/confidentialite">Confidentialité</a>
        <a href="/cgv">CGV</a>
      </div>
    </div>
  </footer>
</template>

<style scoped>
.footer {
  background: var(--forest);
  color: rgba(255,255,255,0.75);
  padding: 5rem 2rem 2rem;
}

.footer__inner {
  max-width: 1280px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 3rem;
  padding-bottom: 3rem;
  border-bottom: 1px solid rgba(255,255,255,0.1);
}

.footer__logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.logo-mark {
  width: 38px;
  height: 38px;
  background: var(--terracotta);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-display);
  font-weight: 900;
  font-size: 1.2rem;
}

.logo-text {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 1.6rem;
  color: white;
}

.footer__tagline {
  font-size: 0.95rem;
  line-height: 1.7;
  margin-bottom: 1.5rem;
  color: rgba(255,255,255,0.6);
  font-style: italic;
  font-family: var(--font-display);
}

.footer__social {
  display: flex;
  gap: 0.75rem;
}

.social-link {
  width: 38px;
  height: 38px;
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255,255,255,0.7);
  transition: all 0.2s;
}

.social-link:hover {
  border-color: var(--terracotta);
  color: var(--terracotta);
}

.footer__col h4 {
  font-family: var(--font-display);
  font-size: 1rem;
  color: white;
  margin-bottom: 1.25rem;
}

.footer__col ul {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.footer__col ul li a,
.footer__col ul li {
  font-size: 0.9rem;
  transition: color 0.2s;
}

.footer__col ul li a:hover {
  color: var(--ochre-light);
}

.footer__zone {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  font-size: 0.9rem;
}

.footer__bottom {
  max-width: 1280px;
  margin: 0 auto;
  padding-top: 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.8rem;
  color: rgba(255,255,255,0.4);
  flex-wrap: wrap;
  gap: 0.5rem;
}

.footer__legal {
  display: flex;
  gap: 1.5rem;
}

.footer__legal a:hover {
  color: rgba(255,255,255,0.7);
}

@media (max-width: 900px) {
  .footer__inner {
    grid-template-columns: 1fr 1fr;
  }
  .footer__brand {
    grid-column: 1 / -1;
  }
}

@media (max-width: 600px) {
  .footer__inner {
    grid-template-columns: 1fr;
  }
  .footer__bottom {
    flex-direction: column;
    text-align: center;
  }
}
</style>
