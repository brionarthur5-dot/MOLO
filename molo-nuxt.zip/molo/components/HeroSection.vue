<template>
  <section class="hero">
    <div class="hero__blob hero__blob--1"></div>
    <div class="hero__blob hero__blob--2"></div>

    <div class="hero__inner">
      <div class="hero__content">
        <div class="hero__badge">
          <span class="badge-dot"></span>
          Service disponible dans la métropole lilloise
        </div>

        <h1 class="hero__title">
          Votre cuisine du<br>
          <span class="highlight">quotidien,</span><br>
          sans le stress
        </h1>

        <p class="hero__subtitle">
          Un chef vient chez vous et prépare <strong>5 à 7 repas faits maison</strong> pour toute la semaine. 
          Sain, savoureux, et taillé sur-mesure pour vos goûts.
        </p>

        <div class="hero__actions">
          <NuxtLink to="/reserver" class="btn btn--primary">
            Réserver ma session
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </NuxtLink>
          <a href="#comment" class="btn btn--ghost">
            Comment ça marche
          </a>
        </div>

        <div class="hero__stats">
          <div class="stat">
            <span class="stat__num">2h</span>
            <span class="stat__label">de préparation<br>par semaine gagnées</span>
          </div>
          <div class="stat-divider"></div>
          <div class="stat">
            <span class="stat__num">150+</span>
            <span class="stat__label">familles<br>satisfaites</span>
          </div>
          <div class="stat-divider"></div>
          <div class="stat">
            <span class="stat__num">4.9★</span>
            <span class="stat__label">note moyenne<br>clients</span>
          </div>
        </div>
      </div>

      <div class="hero__visual">
        <div class="hero__card hero__card--main">
          <div class="card-emoji">🥘</div>
          <div class="card-content">
            <div class="card-title">Menu de la semaine</div>
            <div class="card-items">
              <div class="menu-item">
                <span class="menu-day">Lun</span>
                <span class="menu-dish">Tajine de légumes & pois chiches</span>
              </div>
              <div class="menu-item">
                <span class="menu-day">Mar</span>
                <span class="menu-dish">Poulet rôti aux herbes</span>
              </div>
              <div class="menu-item">
                <span class="menu-day">Mer</span>
                <span class="menu-dish">Gratin dauphinois & salade</span>
              </div>
              <div class="menu-item">
                <span class="menu-day">Jeu</span>
                <span class="menu-dish">Lasagnes maison</span>
              </div>
              <div class="menu-item">
                <span class="menu-day">Ven</span>
                <span class="menu-dish">Curry de crevettes & riz</span>
              </div>
            </div>
          </div>
        </div>

        <div class="hero__card hero__card--float hero__card--float1">
          <span>✅ Personnalisé</span>
          <span class="card-sub">selon vos goûts</span>
        </div>

        <div class="hero__card hero__card--float hero__card--float2">
          <span>🌿 100% frais</span>
          <span class="card-sub">produits locaux</span>
        </div>

        <div class="hero__card hero__card--float hero__card--float3">
          <span>📍 Lille</span>
          <span class="card-sub">& métropole</span>
        </div>
      </div>
    </div>

    <div class="hero__wave">
      <svg viewBox="0 0 1440 100" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
        <path d="M0 50 C360 100 1080 0 1440 50 L1440 100 L0 100 Z" fill="#FAF6F0"/>
      </svg>
    </div>
  </section>
</template>

<style scoped>
.hero {
  min-height: 100vh;
  background: linear-gradient(135deg, var(--forest) 0%, #3D4F32 50%, #2D3B27 100%);
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  padding-top: 90px;
}

.hero__blob {
  position: absolute;
  border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%;
  animation: blob 8s ease-in-out infinite;
  opacity: 0.12;
}

.hero__blob--1 {
  width: 500px;
  height: 500px;
  background: var(--terracotta);
  top: -100px;
  right: -100px;
  animation-delay: 0s;
}

.hero__blob--2 {
  width: 350px;
  height: 350px;
  background: var(--ochre);
  bottom: 100px;
  left: -80px;
  animation-delay: -4s;
}

.hero__inner {
  flex: 1;
  max-width: 1280px;
  margin: 0 auto;
  padding: 4rem 2rem 6rem;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: center;
  position: relative;
  z-index: 2;
}

.hero__badge {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  color: rgba(255,255,255,0.85);
  padding: 0.4rem 1rem;
  border-radius: 50px;
  font-size: 0.82rem;
  margin-bottom: 1.5rem;
  animation: fadeUp 0.6s ease forwards;
}

.badge-dot {
  width: 8px;
  height: 8px;
  background: var(--ochre);
  border-radius: 50%;
  animation: float 2s ease-in-out infinite;
}

.hero__title {
  font-family: var(--font-display);
  font-size: clamp(2.5rem, 5vw, 4.2rem);
  font-weight: 900;
  color: white;
  line-height: 1.1;
  margin-bottom: 1.5rem;
  animation: fadeUp 0.6s 0.1s ease both;
}

.highlight {
  color: var(--ochre-light);
  font-style: italic;
}

.hero__subtitle {
  font-size: 1.1rem;
  color: rgba(255,255,255,0.75);
  line-height: 1.7;
  margin-bottom: 2.5rem;
  max-width: 500px;
  animation: fadeUp 0.6s 0.2s ease both;
}

.hero__subtitle strong {
  color: white;
}

.hero__actions {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
  margin-bottom: 3rem;
  animation: fadeUp 0.6s 0.3s ease both;
}

.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.9rem 1.8rem;
  border-radius: 50px;
  font-size: 1rem;
  font-weight: 500;
  transition: all 0.3s ease;
  cursor: pointer;
}

.btn--primary {
  background: var(--terracotta);
  color: white;
}

.btn--primary:hover {
  background: var(--terracotta-light);
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(196, 98, 45, 0.4);
}

.btn--ghost {
  background: rgba(255,255,255,0.1);
  color: white;
  border: 1px solid rgba(255,255,255,0.3);
}

.btn--ghost:hover {
  background: rgba(255,255,255,0.2);
}

.hero__stats {
  display: flex;
  gap: 1.5rem;
  align-items: center;
  animation: fadeUp 0.6s 0.4s ease both;
}

.stat__num {
  display: block;
  font-family: var(--font-display);
  font-size: 1.8rem;
  font-weight: 700;
  color: white;
}

.stat__label {
  display: block;
  font-size: 0.78rem;
  color: rgba(255,255,255,0.5);
  line-height: 1.4;
}

.stat-divider {
  width: 1px;
  height: 40px;
  background: rgba(255,255,255,0.2);
}

/* Visual cards */
.hero__visual {
  position: relative;
  animation: fadeIn 0.8s 0.5s ease both;
}

.hero__card {
  background: white;
  border-radius: var(--radius);
  box-shadow: 0 20px 60px rgba(0,0,0,0.2);
}

.hero__card--main {
  padding: 1.75rem;
  display: flex;
  gap: 1.25rem;
}

.card-emoji {
  font-size: 2.5rem;
  flex-shrink: 0;
}

.card-title {
  font-family: var(--font-display);
  font-weight: 700;
  color: var(--forest);
  margin-bottom: 1rem;
  font-size: 1rem;
}

.card-items {
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-size: 0.85rem;
}

.menu-day {
  background: var(--cream);
  color: var(--terracotta);
  font-weight: 600;
  font-size: 0.75rem;
  padding: 0.2rem 0.5rem;
  border-radius: 4px;
  flex-shrink: 0;
}

.menu-dish {
  color: var(--text);
}

.hero__card--float {
  position: absolute;
  padding: 0.75rem 1rem;
  border-radius: var(--radius-sm);
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--forest);
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  animation: float 4s ease-in-out infinite;
}

.card-sub {
  font-size: 0.72rem;
  font-weight: 400;
  color: var(--text-muted);
}

.hero__card--float1 {
  top: -20px;
  right: -20px;
  animation-delay: 0s;
}

.hero__card--float2 {
  bottom: 60px;
  right: -30px;
  animation-delay: 1.5s;
}

.hero__card--float3 {
  bottom: -20px;
  left: 20px;
  animation-delay: 0.75s;
}

.hero__wave {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100px;
}

.hero__wave svg {
  width: 100%;
  height: 100%;
}

@media (max-width: 1000px) {
  .hero__inner {
    grid-template-columns: 1fr;
    text-align: center;
  }
  .hero__subtitle { margin: 0 auto 2.5rem; }
  .hero__actions { justify-content: center; }
  .hero__stats { justify-content: center; }
  .hero__visual { display: none; }
}
</style>
