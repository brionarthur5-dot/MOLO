<template>
  <section id="menus" class="menus section">
    <div class="container">
      <div class="section-header">
        <span class="section-label">Ce qu'on prépare</span>
        <h2 class="section-title">Des menus fait-maison,<br>adaptés à chacun</h2>
      </div>

      <div class="menus__tabs">
        <button
          v-for="cat in categories"
          :key="cat.id"
          :class="['tab', { 'tab--active': activeCategory === cat.id }]"
          @click="activeCategory = cat.id"
        >
          {{ cat.icon }} {{ cat.label }}
        </button>
      </div>

      <transition name="fade" mode="out-in">
        <div class="menus__grid" :key="activeCategory">
          <div class="menu-card" v-for="menu in currentMenus" :key="menu.name">
            <div class="menu-card__emoji">{{ menu.emoji }}</div>
            <div class="menu-card__body">
              <div class="menu-card__tags">
                <span class="tag" v-for="tag in menu.tags" :key="tag">{{ tag }}</span>
              </div>
              <h3 class="menu-card__title">{{ menu.name }}</h3>
              <p class="menu-card__desc">{{ menu.desc }}</p>
            </div>
          </div>
        </div>
      </transition>

      <div class="menus__cta">
        <p>Nos menus changent chaque semaine selon la saison et vos envies.</p>
        <NuxtLink to="/reserver" class="btn-outline">Voir comment personnaliser →</NuxtLink>
      </div>
    </div>
  </section>
</template>

<script setup>
const activeCategory = ref('familial')

const categories = [
  { id: 'familial', icon: '👨‍👩‍👧', label: 'Familial' },
  { id: 'veggie', icon: '🌿', label: 'Végétarien' },
  { id: 'fitness', icon: '💪', label: 'Fitness' },
  { id: 'gourmand', icon: '🍷', label: 'Gourmand' },
]

const menus = {
  familial: [
    { emoji: '🥘', name: 'Tajine de légumes', desc: 'Carottes, courgettes, pois chiches et épices douces. Un plat réconfortant pour toute la famille.', tags: ['Végétarien', 'Sans gluten'] },
    { emoji: '🍗', name: 'Poulet rôti aux herbes', desc: 'Cuisiné au four avec thym, romarin et citron. Accompagné de pommes de terre grenaille.', tags: ['Sans lactose', 'Facile'] },
    { emoji: '🍝', name: 'Lasagnes maison', desc: 'Sauce bolognaise mijotée 3h, béchamel onctueuse et gratin parfait. La vraie lasagne d\'amore.', tags: ['Fait maison', 'Réconfortant'] },
    { emoji: '🐟', name: 'Filet de saumon citronné', desc: 'Saumon frais mariné, riz basmati et légumes vapeur. Léger et délicieux.', tags: ['Riche en Oméga 3', 'Rapide'] },
    { emoji: '🫕', name: 'Soupe de lentilles corail', desc: 'Lentilles corail, lait de coco, curcuma et gingembre. Parfaite pour les soirées d\'hiver.', tags: ['Vegan', 'Protéiné'] },
    { emoji: '🥩', name: 'Bœuf bourguignon', desc: 'Mijoté 4h avec carottes, champignons et vin rouge. La recette de nos grands-mères, enfin accessible chaque semaine.', tags: ['Traditionnel', 'Mijoté'] },
  ],
  veggie: [
    { emoji: '🥗', name: 'Buddha bowl coloré', desc: 'Quinoa, pois chiches rôtis, avocat, betterave et sauce tahini maison.', tags: ['Vegan', 'Sans gluten'] },
    { emoji: '🧆', name: 'Falafels & sauce yaourt', desc: 'Falafels croustillants, salade fraîche, tomates cerises et sauce au yaourt à l\'ail.', tags: ['Végétarien', 'Protéiné'] },
    { emoji: '🍄', name: 'Risotto aux champignons', desc: 'Champignons de Paris et shiitakés, parmesan, vin blanc et persil frais.', tags: ['Végétarien', 'Crémeux'] },
    { emoji: '🫔', name: 'Wraps de légumes rôtis', desc: 'Poivrons, aubergines, courgettes rôties avec houmous maison dans une galette de blé.', tags: ['Vegan', 'Facile'] },
    { emoji: '🥧', name: 'Quiche épinards-feta', desc: 'Pâte brisée maison, épinards frais, feta et muscade. Un classique revisité.', tags: ['Végétarien', 'Fait maison'] },
    { emoji: '🍲', name: 'Dahl de lentilles', desc: 'Lentilles vertes, tomates concassées, garam masala et coriandre fraîche. Réconfortant et nourrissant.', tags: ['Vegan', 'Épicé doux'] },
  ],
  fitness: [
    { emoji: '🍗', name: 'Blanc de poulet prep', desc: 'Filets de poulet grillés au four, riz brun et brocolis vapeur. Le classique meal prep sportif.', tags: ['High Protein', 'Low Fat'] },
    { emoji: '🐟', name: 'Saumon & patate douce', desc: 'Saumon grillé riche en Oméga 3, purée de patate douce et haricots verts.', tags: ['Oméga 3', 'Sans gluten'] },
    { emoji: '🥚', name: 'Omelettes protéinées', desc: '3 œufs, champignons, épinards, fromage blanc. Rapide, satiétant et boosté en protéines.', tags: ['High Protein', 'Low Carb'] },
    { emoji: '🫛', name: 'Bowl protéiné veggie', desc: 'Edamame, tofu mariné, quinoa rouge et sauce sésame-gingembre.', tags: ['Vegan', 'Protéiné'] },
    { emoji: '🥗', name: 'Salade niçoise prep', desc: 'Thon en conserve premium, œufs durs, haricots verts, olives et vinaigrette légère.', tags: ['Sans gluten', 'Light'] },
    { emoji: '🍖', name: 'Bœuf & légumes wok', desc: 'Lamelles de bœuf, brocoli, carottes et sauce tamari-gingembre. Riche en protéines et en saveurs.', tags: ['High Protein', 'Rapide'] },
  ],
  gourmand: [
    { emoji: '🍮', name: 'Crème brûlée vanille', desc: 'Vanille Bourbon de Madagascar, caramel craquant à la minute. Le dessert préféré des Français.', tags: ['Dessert', 'Signature'] },
    { emoji: '🥐', name: 'Blanquette de veau', desc: 'Veau fondant, champignons, crème fraîche et citron. La grande cuisine française accessible.', tags: ['Traditionnel', 'Crémeux'] },
    { emoji: '🦞', name: 'Risotto aux fruits de mer', desc: 'Crevettes, moules et Saint-Jacques, arborio crémeux, vin blanc et parmesan vieilli.', tags: ['Luxe', 'Sans gluten'] },
    { emoji: '🍫', name: 'Mi-cuit au chocolat', desc: 'Chocolat 70% fondant, coulant dedans, croustillant dehors. Pour les soirs de semaine qui méritent mieux.', tags: ['Dessert', 'Indulgent'] },
    { emoji: '🥩', name: 'Magret de canard', desc: 'Magret rosé avec sa sauce au miel et figues, accompagné de gratin dauphinois.', tags: ['Gastronomique', 'Sans gluten'] },
    { emoji: '🍰', name: 'Tarte tatin maison', desc: 'Pommes caramélisées, pâte feuilletée maison et crème fraîche. Un dessert qui fait la différence.', tags: ['Dessert', 'Fait maison'] },
  ]
}

const currentMenus = computed(() => menus[activeCategory.value])
</script>

<style scoped>
.menus {
  padding: 6rem 2rem;
  background: var(--warm-white);
}

.container {
  max-width: 1280px;
  margin: 0 auto;
}

.section-header {
  text-align: center;
  margin-bottom: 3rem;
}

.section-label {
  display: inline-block;
  font-family: var(--font-accent);
  font-size: 1.1rem;
  color: var(--terracotta);
  margin-bottom: 0.5rem;
}

.section-title {
  font-family: var(--font-display);
  font-size: clamp(2rem, 4vw, 3rem);
  font-weight: 900;
  color: var(--forest);
}

.menus__tabs {
  display: flex;
  justify-content: center;
  gap: 0.75rem;
  flex-wrap: wrap;
  margin-bottom: 3rem;
}

.tab {
  padding: 0.6rem 1.25rem;
  border-radius: 50px;
  font-size: 0.9rem;
  font-weight: 500;
  background: var(--sand);
  color: var(--text-muted);
  border: 2px solid transparent;
  transition: all 0.25s ease;
}

.tab:hover {
  background: var(--cream);
  color: var(--text);
}

.tab--active {
  background: var(--terracotta);
  color: white;
  border-color: var(--terracotta);
}

.menus__grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
  margin-bottom: 3rem;
}

.menu-card {
  background: white;
  border-radius: var(--radius);
  padding: 1.5rem;
  display: flex;
  gap: 1rem;
  border: 2px solid transparent;
  transition: all 0.3s ease;
}

.menu-card:hover {
  border-color: var(--sand);
  box-shadow: 0 8px 30px rgba(0,0,0,0.08);
  transform: translateY(-2px);
}

.menu-card__emoji {
  font-size: 2.5rem;
  flex-shrink: 0;
}

.menu-card__tags {
  display: flex;
  gap: 0.4rem;
  flex-wrap: wrap;
  margin-bottom: 0.5rem;
}

.tag {
  background: var(--cream);
  color: var(--sage);
  font-size: 0.72rem;
  font-weight: 500;
  padding: 0.15rem 0.6rem;
  border-radius: 50px;
}

.menu-card__title {
  font-family: var(--font-display);
  font-size: 1rem;
  font-weight: 700;
  color: var(--forest);
  margin-bottom: 0.4rem;
}

.menu-card__desc {
  font-size: 0.85rem;
  color: var(--text-muted);
  line-height: 1.5;
}

.menus__cta {
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
}

.menus__cta p {
  color: var(--text-muted);
  font-style: italic;
}

.btn-outline {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  border-radius: 50px;
  border: 2px solid var(--terracotta);
  color: var(--terracotta);
  font-weight: 500;
  font-size: 0.95rem;
  transition: all 0.3s ease;
}

.btn-outline:hover {
  background: var(--terracotta);
  color: white;
}

/* Transition */
.fade-enter-active, .fade-leave-active { transition: opacity 0.25s ease; }
.fade-enter-from, .fade-leave-to { opacity: 0; }

@media (max-width: 1000px) {
  .menus__grid { grid-template-columns: 1fr 1fr; }
}

@media (max-width: 600px) {
  .menus__grid { grid-template-columns: 1fr; }
}
</style>
