<template>
  <section id="comment" class="how-it-works section">
    <div class="container">
      <div class="section-header">
        <span class="section-label">Simple comme bonjour</span>
        <h2 class="section-title">Comment fonctionne Molo ?</h2>
        <p class="section-desc">En 4 étapes simples, on s'occupe de tout. Vous n'avez plus qu'à réchauffer et déguster.</p>
      </div>

      <div class="steps">
        <div class="step" v-for="(step, index) in steps" :key="step.title">
          <div class="step__num">{{ index + 1 }}</div>
          <div class="step__icon">{{ step.icon }}</div>
          <h3 class="step__title">{{ step.title }}</h3>
          <p class="step__desc">{{ step.desc }}</p>
          <div class="step__arrow" v-if="index < steps.length - 1">→</div>
        </div>
      </div>

      <div class="how-it-works__note">
        <span class="note-accent">💡</span>
        <p>Vous disposez de vos boîtes étiquetées avec les noms des plats, les jours suggérés et le temps de réchauffage. Tout est prêt pour une semaine sereine !</p>
      </div>
    </div>
  </section>
</template>

<script setup>
const steps = [
  {
    icon: '📅',
    title: 'Choisissez votre créneau',
    desc: 'Sélectionnez un jour et une heure qui vous conviennent. Nous intervenons du lundi au samedi, sur toute la métropole.'
  },
  {
    icon: '🥗',
    title: 'Partagez vos préférences',
    desc: 'Régimes alimentaires, allergies, plats favoris, nombre de personnes — on personnalise le menu pour vous.'
  },
  {
    icon: '🍳',
    title: 'Votre chef cuisine chez vous',
    desc: 'Un·e cuisinier·e professionnel·le vient avec les courses et prépare 5 à 7 repas dans votre cuisine.'
  },
  {
    icon: '🥡',
    title: 'Réchauffez & savourez',
    desc: 'Vos plats sont conditionnés en boîtes hermétiques, étiquetées et rangés. Profitez de votre semaine !'
  }
]
</script>

<style scoped>
.how-it-works {
  padding: 6rem 2rem;
  background: var(--cream);
}

.container {
  max-width: 1280px;
  margin: 0 auto;
}

.section-header {
  text-align: center;
  margin-bottom: 4rem;
}

.section-label {
  display: inline-block;
  font-family: var(--font-accent);
  font-size: 1.1rem;
  color: var(--terracotta);
  margin-bottom: 0.5rem;
}

.section-title {
  font-family: var(--font-display);
  font-size: clamp(2rem, 4vw, 3rem);
  font-weight: 900;
  color: var(--forest);
  margin-bottom: 1rem;
}

.section-desc {
  color: var(--text-muted);
  font-size: 1.05rem;
  max-width: 550px;
  margin: 0 auto;
}

.steps {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 2rem;
  position: relative;
  margin-bottom: 3rem;
}

.step {
  position: relative;
  background: white;
  border-radius: var(--radius);
  padding: 2rem 1.5rem;
  text-align: center;
  border: 2px solid transparent;
  transition: all 0.3s ease;
}

.step:hover {
  border-color: var(--terracotta);
  transform: translateY(-4px);
  box-shadow: 0 12px 40px rgba(196, 98, 45, 0.12);
}

.step__num {
  position: absolute;
  top: -16px;
  left: 50%;
  transform: translateX(-50%);
  width: 32px;
  height: 32px;
  background: var(--terracotta);
  color: white;
  border-radius: 50%;
  font-size: 0.85rem;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
}

.step__icon {
  font-size: 2.5rem;
  margin-bottom: 1rem;
  margin-top: 0.5rem;
}

.step__title {
  font-family: var(--font-display);
  font-size: 1.05rem;
  font-weight: 700;
  color: var(--forest);
  margin-bottom: 0.75rem;
}

.step__desc {
  font-size: 0.9rem;
  color: var(--text-muted);
  line-height: 1.6;
}

.step__arrow {
  position: absolute;
  top: 50%;
  right: -22px;
  transform: translateY(-50%);
  font-size: 1.5rem;
  color: var(--sand);
  z-index: 2;
}

.how-it-works__note {
  background: linear-gradient(135deg, rgba(212, 168, 67, 0.12), rgba(196, 98, 45, 0.08));
  border-radius: var(--radius);
  padding: 1.5rem 2rem;
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  border: 1px solid var(--sand);
}

.note-accent {
  font-size: 1.5rem;
  flex-shrink: 0;
}

.how-it-works__note p {
  color: var(--text);
  font-size: 0.95rem;
  line-height: 1.7;
}

@media (max-width: 900px) {
  .steps {
    grid-template-columns: 1fr 1fr;
  }
  .step__arrow { display: none; }
}

@media (max-width: 600px) {
  .steps {
    grid-template-columns: 1fr;
  }
}
</style>
