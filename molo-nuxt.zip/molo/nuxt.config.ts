// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  devtools: { enabled: true },
  modules: [
    '@nuxtjs/google-fonts'
  ],
  googleFonts: {
    families: {
      'Playfair+Display': [400, 700, 900],
      'DM+Sans': [300, 400, 500],
      'Caveat': [400, 600],
    }
  },
  css: ['~/assets/css/main.css'],
  app: {
    head: {
      title: 'Molo – Batch cooking à domicile · Métropole lilloise',
      meta: [
        { charset: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { name: 'description', content: 'Molo vous prépare une semaine de repas faits maison, sains et savoureux. Service de batch cooking à domicile dans toute la métropole lilloise.' }
      ],
      link: [
        { rel: 'icon', type: 'image/svg+xml', href: '/favicon.svg' }
      ]
    }
  }
})
